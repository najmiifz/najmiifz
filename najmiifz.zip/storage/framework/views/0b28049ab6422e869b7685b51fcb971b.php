<head>
    <meta charset="UTF-8">
    <title>Register - Hayu Cukur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-light bg-white shadow-sm px-4">
    <a class="navbar-brand d-flex align-items-center" href="/">
        <img src="/images/logo.png" alt="Logo Hayu Cukur" style="height: 40px;" class="me-2">
        <strong>Hayu Cukur</strong>
    </a>
    <div class="ms-auto">
        <a href="/webnajmi" class="btn btn-outline-dark me-2">home</a>
        <a href="/login" class="btn btn-outline-dark me-2">Login</a>
        <a href="/register" class="btn btn-danger">Daftar</a>
    </div>
</nav>

<!-- Form Register -->
<div class="container mt-5" style="max-width: 400px;">
    <h3 class="mb-4 text-center">Daftar</h3>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="/register">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Nama</label>
            <input name="name" type="text" class="form-control" placeholder="Masukkan nama lengkap">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input name="email" type="email" class="form-control" placeholder="Masukkan email">
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input name="password" type="password" class="form-control" placeholder="Masukkan password">
        </div>
        <div class="mb-3">
            <label>Konfirmasi Password</label>
            <input name="password_confirmation" type="password" class="form-control" placeholder="Ulangi password">
        </div>
        <button type="submit" class="btn btn-danger w-100">Daftar</button>
    </form>
</div>

</body>
</html>
<?php /**PATH D:\webtest\najmiifz\resources\views/register.blade.php ENDPATH**/ ?>